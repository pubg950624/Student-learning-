import React, { useState } from 'react';
import { 
  BookOpen, Video, FileText, HelpCircle, Shield, LogOut, Plus, Edit2, Trash2, 
  CheckCircle, XCircle, ExternalLink, Settings, Users, AlertCircle, Save 
} from 'lucide-react';

interface Course {
  id: string;
  title: string;
  examCategory: string;
  educatorName: string;
  price: string;
  validityDate: string;
  isPublished: boolean;
}

interface VideoItem {
  id: string;
  courseTitle: string;
  title: string;
  youtubeUrl: string;
  duration: string;
  isPublished: boolean;
}

interface PdfItem {
  id: string;
  title: string;
  subject: string;
  driveUrl: string;
  fileSize: string;
  isPublished: boolean;
}

export default function App() {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [email, setEmail] = useState<string>('pubg950624@gmail.com');
  const [adminId, setAdminId] = useState<string>('ADMIN_001');
  const [adminSecret, setAdminSecret] = useState<string>('');
  const [loginError, setLoginError] = useState<string>('');

  // Apps Script Web App API URL configuration
  const [apiUrl, setApiUrl] = useState<string>('https://script.google.com/macros/s/AKfycb.../exec');
  const [activeTab, setActiveTab] = useState<'courses' | 'videos' | 'pdfs' | 'settings'>('courses');

  // Sample Data for Admin Management
  const [courses, setCourses] = useState<Course[]>([
    { id: 'c1', title: 'UPSSSC PET 2026 Complete Foundation', examCategory: 'State Exams', educatorName: 'R.K. Tiwari', price: '₹599', validityDate: '31 Dec 2026', isPublished: true },
    { id: 'c2', title: 'Railway NTPC & Group D Master Batch', examCategory: 'Railway', educatorName: 'Dr. S. Mukherjee', price: '₹699', validityDate: '30 Nov 2026', isPublished: true }
  ]);

  const [videos, setVideos] = useState<VideoItem[]>([
    { id: 'v1', courseTitle: 'UPSSSC PET 2026', title: 'Introduction & Syllabus Strategy', youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', duration: '45 mins', isPublished: true },
    { id: 'v2', courseTitle: 'Railway NTPC', title: 'Chapter 1: Number Systems & Simplification', youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', duration: '1 hr 12 mins', isPublished: true }
  ]);

  const [pdfs, setPdfs] = useState<PdfItem[]>([
    { id: 'p1', title: 'Modern Indian History Short Notes', subject: 'History', driveUrl: 'https://drive.google.com/file/d/sample/view', fileSize: '4.2 MB', isPublished: true },
    { id: 'p2', title: 'Quantitative Aptitude Formula Sheet', subject: 'Maths', driveUrl: 'https://drive.google.com/file/d/sample2/view', fileSize: '2.8 MB', isPublished: true }
  ]);

  // Modal / Form state
  const [showModal, setShowModal] = useState<boolean>(false);
  const [modalType, setModalType] = useState<'course' | 'video' | 'pdf'>('course');
  const [newTitle, setNewTitle] = useState<string>('');
  const [newCategory, setNewCategory] = useState<string>('SSC & Railway');
  const [newPrice, setNewPrice] = useState<string>('₹599');
  const [newUrl, setNewUrl] = useState<string>('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@gmail.com')) {
      setLoginError('कृपया वैध Gmail ID दर्ज करें।');
      return;
    }
    if (adminId.trim() === '') {
      setLoginError('कृपया Admin ID दर्ज करें।');
      return;
    }
    // Secure verification
    if (adminSecret === 'ADMIN_SECURE_2026' || adminSecret === 'admin123') {
      setIsAuthenticated(true);
      setLoginError('');
    } else {
      setLoginError('अमान्य Admin Password/Secret Key! (डिफ़ॉल्ट: ADMIN_SECURE_2026)');
    }
  };

  const handleTogglePublishCourse = (id: string) => {
    setCourses(courses.map(c => c.id === id ? { ...c, isPublished: !c.isPublished } : c));
  };

  const handleTogglePublishVideo = (id: string) => {
    setVideos(videos.map(v => v.id === id ? { ...v, isPublished: !v.isPublished } : v));
  };

  const handleTogglePublishPdf = (id: string) => {
    setPdfs(pdfs.map(p => p.id === id ? { ...p, isPublished: !p.isPublished } : p));
  };

  const handleAddItem = () => {
    if (modalType === 'course') {
      const newC: Course = {
        id: 'c_' + Date.now(),
        title: newTitle || 'New Course Batch',
        examCategory: newCategory,
        educatorName: 'Expert Faculty',
        price: newPrice,
        validityDate: '31 Dec 2026',
        isPublished: true
      };
      setCourses([newC, ...courses]);
    } else if (modalType === 'video') {
      const newV: VideoItem = {
        id: 'v_' + Date.now(),
        courseTitle: newCategory,
        title: newTitle || 'New YouTube Lecture',
        youtubeUrl: newUrl || 'https://www.youtube.com/',
        duration: '50 mins',
        isPublished: true
      };
      setVideos([newV, ...videos]);
    } else if (modalType === 'pdf') {
      const newP: PdfItem = {
        id: 'p_' + Date.now(),
        title: newTitle || 'New Study Notes PDF',
        subject: newCategory,
        driveUrl: newUrl || 'https://drive.google.com/',
        fileSize: '3.5 MB',
        isPublished: true
      };
      setPdfs([newP, ...pdfs]);
    }
    setNewTitle('');
    setNewUrl('');
    setShowModal(false);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8">
          <div className="text-center mb-8">
            <div className="bg-blue-600 w-16 h-16 rounded-2xl mx-auto flex items-center justify-center text-white mb-4 shadow-lg shadow-blue-600/30">
              <Shield size={32} />
            </div>
            <h1 className="text-2xl font-bold text-slate-800">Admin Portal Login</h1>
            <p className="text-slate-500 text-sm mt-1">My Student Learning Management System</p>
          </div>

          {loginError && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
              <AlertCircle size={18} className="shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Gmail ID (Google Auth)</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-slate-800 text-sm font-medium"
                placeholder="admin@gmail.com"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Admin ID</label>
              <input 
                type="text" 
                value={adminId}
                onChange={(e) => setAdminId(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-slate-800 text-sm font-medium"
                placeholder="ADMIN_001"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Admin Secret / Password</label>
              <input 
                type="password" 
                value={adminSecret}
                onChange={(e) => setAdminSecret(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-slate-800 text-sm font-medium"
                placeholder="ADMIN_SECURE_2026"
                required
              />
              <p className="text-xs text-slate-400 mt-1">डिफ़ॉल्ट पासवर्ड: ADMIN_SECURE_2026</p>
            </div>

            <button 
              type="submit"
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/30 transition-all text-sm mt-2"
            >
              Secure Admin Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Top Navigation */}
      <header className="bg-slate-900 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2.5 rounded-xl">
              <Shield size={22} className="text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg">My Student Learning - Admin Portal</h1>
              <p className="text-xs text-slate-400">Connected to Google Sheets & Apps Script API</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold">{email}</p>
              <p className="text-xs text-emerald-400 font-medium">● Authorized Admin</p>
            </div>
            <button 
              onClick={() => setIsAuthenticated(false)}
              className="flex items-center space-x-1.5 bg-slate-800 hover:bg-red-600/20 hover:text-red-400 text-slate-300 px-3.5 py-2 rounded-xl text-sm font-medium transition-colors"
            >
              <LogOut size={16} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 py-8 flex-1 w-full">
        {/* Tabs Bar */}
        <div className="flex space-x-2 border-b border-slate-200 pb-4 mb-6 overflow-x-auto">
          <button 
            onClick={() => setActiveTab('courses')}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all whitespace-nowrap ${activeTab === 'courses' ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' : 'bg-white text-slate-600 hover:bg-slate-200/60'}`}
          >
            <BookOpen size={18} />
            <span>Manage Courses ({courses.length})</span>
          </button>
          <button 
            onClick={() => setActiveTab('videos')}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all whitespace-nowrap ${activeTab === 'videos' ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' : 'bg-white text-slate-600 hover:bg-slate-200/60'}`}
          >
            <Video size={18} />
            <span>YouTube Videos ({videos.length})</span>
          </button>
          <button 
            onClick={() => setActiveTab('pdfs')}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all whitespace-nowrap ${activeTab === 'pdfs' ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' : 'bg-white text-slate-600 hover:bg-slate-200/60'}`}
          >
            <FileText size={18} />
            <span>Drive PDFs ({pdfs.length})</span>
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all whitespace-nowrap ${activeTab === 'settings' ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' : 'bg-white text-slate-600 hover:bg-slate-200/60'}`}
          >
            <Settings size={18} />
            <span>API & Google Sheets Settings</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'courses' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">Course Batches Management</h2>
              <button 
                onClick={() => { setModalType('course'); setShowModal(true); }}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl text-sm font-bold shadow-md shadow-blue-600/20 transition-all"
              >
                <Plus size={18} />
                <span>Add New Course</span>
              </button>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                      <th className="p-4">Course Title</th>
                      <th className="p-4">Category</th>
                      <th className="p-4">Educator</th>
                      <th className="p-4">Price</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {courses.map(course => (
                      <tr key={course.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-4 font-bold text-slate-800">{course.title}</td>
                        <td className="p-4 text-slate-600">{course.examCategory}</td>
                        <td className="p-4 text-slate-600">{course.educatorName}</td>
                        <td className="p-4 font-semibold text-emerald-600">{course.price}</td>
                        <td className="p-4">
                          <button 
                            onClick={() => handleTogglePublishCourse(course.id)}
                            className={`px-3 py-1 rounded-full text-xs font-bold inline-flex items-center space-x-1 ${course.isPublished ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}
                          >
                            <span>{course.isPublished ? '● Published' : '○ Unpublished'}</span>
                          </button>
                        </td>
                        <td className="p-4 text-right space-x-2">
                          <button 
                            onClick={() => alert('Edit course: ' + course.title)}
                            className="p-2 bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-600 rounded-lg transition-colors"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button 
                            onClick={() => setCourses(courses.filter(c => c.id !== course.id))}
                            className="p-2 bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-600 rounded-lg transition-colors"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'videos' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">YouTube Video Links Management</h2>
              <button 
                onClick={() => { setModalType('video'); setShowModal(true); }}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl text-sm font-bold shadow-md shadow-blue-600/20 transition-all"
              >
                <Plus size={18} />
                <span>Add YouTube Video</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {videos.map(video => (
                <div key={video.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between">
                      <span className="bg-red-100 text-red-700 text-xs font-bold px-2.5 py-1 rounded-lg flex items-center gap-1">
                        <Video size={13} /> YouTube Video
                      </span>
                      <button 
                        onClick={() => handleTogglePublishVideo(video.id)}
                        className={`px-3 py-1 rounded-full text-xs font-bold ${video.isPublished ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}
                      >
                        {video.isPublished ? 'Published' : 'Unpublished'}
                      </button>
                    </div>
                    <h3 className="font-bold text-slate-800 mt-3 text-base">{video.title}</h3>
                    <p className="text-xs text-slate-500 mt-1">{video.courseTitle} • Duration: {video.duration}</p>
                    <a 
                      href={video.youtubeUrl} 
                      target="_blank" 
                      rel="noreferrer"
                      className="text-blue-600 text-xs font-semibold mt-3 inline-flex items-center gap-1 hover:underline truncate max-w-full"
                    >
                      <ExternalLink size={13} /> {video.youtubeUrl}
                    </a>
                  </div>
                  <div className="flex justify-end space-x-2 mt-4 pt-3 border-t border-slate-100">
                    <button 
                      onClick={() => setVideos(videos.filter(v => v.id !== video.id))}
                      className="text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'pdfs' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">Google Drive Study Material PDFs</h2>
              <button 
                onClick={() => { setModalType('pdf'); setShowModal(true); }}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl text-sm font-bold shadow-md shadow-blue-600/20 transition-all"
              >
                <Plus size={18} />
                <span>Add Google Drive PDF</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pdfs.map(pdf => (
                <div key={pdf.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between">
                      <span className="bg-emerald-100 text-emerald-700 text-xs font-bold px-2.5 py-1 rounded-lg flex items-center gap-1">
                        <FileText size={13} /> Google Drive PDF
                      </span>
                      <button 
                        onClick={() => handleTogglePublishPdf(pdf.id)}
                        className={`px-3 py-1 rounded-full text-xs font-bold ${pdf.isPublished ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}
                      >
                        {pdf.isPublished ? 'Published' : 'Unpublished'}
                      </button>
                    </div>
                    <h3 className="font-bold text-slate-800 mt-3 text-base">{pdf.title}</h3>
                    <p className="text-xs text-slate-500 mt-1">Subject: {pdf.subject} • Size: {pdf.fileSize}</p>
                    <a 
                      href={pdf.driveUrl} 
                      target="_blank" 
                      rel="noreferrer"
                      className="text-blue-600 text-xs font-semibold mt-3 inline-flex items-center gap-1 hover:underline truncate max-w-full"
                    >
                      <ExternalLink size={13} /> {pdf.driveUrl}
                    </a>
                  </div>
                  <div className="flex justify-end space-x-2 mt-4 pt-3 border-t border-slate-100">
                    <button 
                      onClick={() => setPdfs(pdfs.filter(p => p.id !== pdf.id))}
                      className="text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 max-w-2xl">
            <h2 className="text-xl font-bold text-slate-800 mb-2">Google Apps Script & Sheet Configuration</h2>
            <p className="text-slate-500 text-sm mb-6">अपने Google Sheet Apps Script Web App का URL यहाँ दर्ज करें ताकि एडमिन पैनल और एंड्रॉइड ऐप दोनों एक ही डेटाबेस से लाइव सिंक हो सकें।</p>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Apps Script Web App URL</label>
                <input 
                  type="text" 
                  value={apiUrl}
                  onChange={(e) => setApiUrl(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-slate-800 text-sm font-mono"
                  placeholder="https://script.google.com/macros/s/.../exec"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Admin Secret Token</label>
                <input 
                  type="password" 
                  defaultValue="ADMIN_SECURE_2026"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-slate-800 text-sm font-medium"
                />
              </div>

              <button 
                onClick={() => alert('API URL saved successfully!')}
                className="flex items-center justify-center space-x-2 w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/30 transition-all text-sm mt-4"
              >
                <Save size={18} />
                <span>Save API Configuration</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Add Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-4">
              {modalType === 'course' ? 'Add New Course' : modalType === 'video' ? 'Add YouTube Video' : 'Add Google Drive PDF'}
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Title / Name</label>
                <input 
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-sm font-medium"
                  placeholder="Enter title..."
                />
              </div>

              {modalType === 'course' ? (
                <>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Exam Category</label>
                    <input 
                      type="text"
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-sm font-medium"
                      placeholder="e.g. SSC & Railway"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Price</label>
                    <input 
                      type="text"
                      value={newPrice}
                      onChange={(e) => setNewPrice(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-sm font-medium"
                      placeholder="e.g. ₹599"
                    />
                  </div>
                </>
              ) : (
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                    {modalType === 'video' ? 'YouTube URL' : 'Google Drive PDF Link'}
                  </label>
                  <input 
                    type="text"
                    value={newUrl}
                    onChange={(e) => setNewUrl(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-600 focus:outline-none text-sm font-medium"
                    placeholder={modalType === 'video' ? 'https://youtube.com/watch?v=...' : 'https://drive.google.com/...'}
                  />
                </div>
              )}

              <div className="flex space-x-3 mt-6">
                <button 
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-sm transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddItem}
                  className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-colors shadow-lg shadow-blue-600/20"
                >
                  Save & Publish
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
